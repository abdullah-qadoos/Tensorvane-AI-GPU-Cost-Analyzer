"""
Synthetic data generator for the NV-A AI Tabular Data Analyzer.

Produces:
  clean/gpu_usage_clean.csv          realistic GPU cloud usage, one row per day x partner x cluster
  clean/mill_production_clean.csv    a second, unrelated domain to prove schema flexibility
  messy/*.csv                        broken variants for testing the data-quality layer
  ground_truth.json                  exactly what was injected into each messy file
  DATA_DICTIONARY.md                 column definitions and the business story baked into the data

Everything is seeded, so re-running produces identical files.
All partner, cluster and mill names are invented.
"""

import json
import os
from datetime import date, timedelta

import numpy as np
import pandas as pd

SEED = 42
rng = np.random.default_rng(SEED)

OUT = os.path.dirname(os.path.abspath(__file__))
CLEAN = os.path.join(OUT, "clean")
MESSY = os.path.join(OUT, "messy")
os.makedirs(CLEAN, exist_ok=True)
os.makedirs(MESSY, exist_ok=True)

START = date(2026, 7, 1)
DAYS = 123  # 1 Jul - 31 Oct 2026
DATES = [START + timedelta(days=i) for i in range(DAYS)]

# ---------------------------------------------------------------------------
# 1. GPU usage dataset
# ---------------------------------------------------------------------------

# Price per GPU-hour in USD by GPU type and contract type (invented but plausible)
PRICE = {
    "H100": {"reserved": 2.45, "on_demand": 3.40, "spot": 1.65},
    "H200": {"reserved": 3.10, "on_demand": 4.30, "spot": 2.10},
    "B200": {"reserved": 4.60, "on_demand": 6.20, "spot": 3.20},
    "A100": {"reserved": 1.35, "on_demand": 1.95, "spot": 0.90},
    "L40S": {"reserved": 0.80, "on_demand": 1.15, "spot": 0.55},
}

CLUSTERS = {
    # cluster_id: (region, gpu_type, total_gpus)
    "use1-h100-a": ("us-east", "H100", 2048),
    "use1-b200-a": ("us-east", "B200", 1024),
    "usw2-h200-a": ("us-west", "H200", 1536),
    "usw2-a100-b": ("us-west", "A100", 1024),
    "euw1-h100-a": ("eu-west", "H100", 1024),
    "euw1-l40s-a": ("eu-west", "L40S", 512),
    "apse1-h100-a": ("ap-southeast", "H100", 768),
    "apse1-a100-a": ("ap-southeast", "A100", 512),
}

# Each partner: clusters used, base GPUs allocated per cluster, contract type, and a
# trend story. Trend = daily multiplicative growth; events are applied separately.
PARTNERS = {
    "Northwind AI":       {"clusters": ["use1-h100-a", "use1-b200-a"], "base": [320, 96], "contract": "reserved", "trend": 0.0045, "story": "steady strong growth, starts on B200 in August"},
    "Helix Robotics":     {"clusters": ["usw2-h200-a", "usw2-a100-b"], "base": [256, 128], "contract": "reserved", "trend": 0.0015, "story": "stable, large"},
    "Quanta Labs":        {"clusters": ["euw1-h100-a"], "base": [180], "contract": "on_demand", "trend": -0.006, "story": "declining, likely churn risk"},
    "Meridian Health AI": {"clusters": ["euw1-l40s-a", "euw1-h100-a"], "base": [140, 60], "contract": "reserved", "trend": 0.0010, "story": "stable inference workload, low failures"},
    "Kestrel Vision":     {"clusters": ["apse1-h100-a", "apse1-a100-a"], "base": [90, 160], "contract": "on_demand", "trend": 0.0025, "story": "growing, spiky on weekdays"},
    "Atlas Genomics":     {"clusters": ["usw2-a100-b"], "base": [110], "contract": "spot", "trend": 0.0, "story": "spot user, very volatile"},
    "Lumen Speech":       {"clusters": ["use1-h100-a", "apse1-h100-a"], "base": [0, 0], "contract": "on_demand", "trend": 0.0, "story": "new partner, onboarded 15 Sep and ramps fast"},
    "Orbit Finance ML":   {"clusters": ["euw1-l40s-a"], "base": [70], "contract": "reserved", "trend": 0.0005, "story": "small, stable"},
}

FAILURE_REASONS = ["OOM", "NCCL_TIMEOUT", "NODE_FAILURE", "PREEMPTED", "USER_ERROR", "DRIVER_ERROR"]

# Business events baked into the data, so the analyzer has real things to find
EVENTS = {
    "outage_usw2": date(2026, 8, 19),          # usw2 clusters: node failures spike, usage drops
    "b200_launch": date(2026, 8, 4),           # Northwind starts using B200
    "lumen_onboard": date(2026, 9, 15),        # Lumen Speech starts
    "quanta_cut": date(2026, 10, 1),           # Quanta cuts allocation by 40%
    "price_change_h100": date(2026, 9, 1),     # H100 on-demand price drops 8%
}

rows = []
for partner, cfg in PARTNERS.items():
    for ci, cluster_id in enumerate(cfg["clusters"]):
        region, gpu_type, total = CLUSTERS[cluster_id]
        base = cfg["base"][ci]
        for d_idx, d in enumerate(DATES):
            # --- allocation story ---
            alloc = base * (1 + cfg["trend"]) ** d_idx

            if partner == "Northwind AI" and gpu_type == "B200":
                if d < EVENTS["b200_launch"]:
                    continue
                days_in = (d - EVENTS["b200_launch"]).days
                alloc = 96 * min(1 + days_in / 30, 3.2)

            if partner == "Lumen Speech":
                if d < EVENTS["lumen_onboard"]:
                    continue
                days_in = (d - EVENTS["lumen_onboard"]).days
                target = 220 if cluster_id == "use1-h100-a" else 80
                alloc = target * (1 - np.exp(-days_in / 9))
                if alloc < 4:
                    alloc = 4

            if partner == "Quanta Labs" and d >= EVENTS["quanta_cut"]:
                alloc *= 0.6

            # weekday / weekend pattern
            weekday = d.weekday()
            if partner == "Kestrel Vision":
                alloc *= 1.15 if weekday < 5 else 0.55
            else:
                alloc *= 1.0 if weekday < 5 else 0.85

            # noise
            noise_sd = 0.18 if cfg["contract"] == "spot" else 0.05
            alloc *= max(0.3, rng.normal(1.0, noise_sd))

            gpus_allocated = int(max(1, round(alloc)))
            gpus_allocated = min(gpus_allocated, total)

            # utilization
            util = rng.normal(78 if cfg["contract"] != "spot" else 64, 7)
            if partner == "Meridian Health AI":
                util = rng.normal(55, 5)  # inference, lower util
            if partner == "Quanta Labs" and d >= date(2026, 9, 10):
                util = rng.normal(48, 8)  # under-using what they pay for

            # outage
            outage = region == "us-west" and d == EVENTS["outage_usw2"]
            if outage:
                util *= 0.35
            util = float(np.clip(util, 5, 99.5))

            gpu_hours = round(gpus_allocated * 24 * util / 100, 1)

            # jobs
            jobs_per_gpu = 0.9 if partner != "Meridian Health AI" else 3.5
            jobs_submitted = int(max(1, rng.poisson(gpus_allocated * jobs_per_gpu * (1.0 if weekday < 5 else 0.7))))
            fail_rate = 0.02 if cfg["contract"] != "spot" else 0.07
            if partner == "Meridian Health AI":
                fail_rate = 0.006
            if outage:
                fail_rate = 0.38
            jobs_failed = int(rng.binomial(jobs_submitted, min(fail_rate, 0.95)))

            if jobs_failed == 0:
                top_reason = ""
            elif outage:
                top_reason = "NODE_FAILURE"
            elif cfg["contract"] == "spot":
                top_reason = rng.choice(["PREEMPTED", "OOM", "NODE_FAILURE"], p=[0.6, 0.25, 0.15])
            else:
                top_reason = rng.choice(FAILURE_REASONS, p=[0.34, 0.2, 0.12, 0.04, 0.24, 0.06])

            # cost
            price = PRICE[gpu_type][cfg["contract"]]
            if gpu_type == "H100" and cfg["contract"] == "on_demand" and d >= EVENTS["price_change_h100"]:
                price = round(price * 0.92, 2)
            # reserved partners pay for allocation; others pay for hours used
            if cfg["contract"] == "reserved":
                billable_hours = gpus_allocated * 24
            else:
                billable_hours = gpu_hours
            cost_usd = round(billable_hours * price, 2)

            rows.append({
                "date": d.isoformat(),
                "partner": partner,
                "region": region,
                "cluster_id": cluster_id,
                "gpu_type": gpu_type,
                "contract_type": cfg["contract"],
                "gpus_allocated": gpus_allocated,
                "gpu_hours": gpu_hours,
                "avg_utilization_pct": round(util, 1),
                "jobs_submitted": jobs_submitted,
                "jobs_failed": jobs_failed,
                "top_failure_reason": top_reason,
                "price_per_gpu_hour_usd": price,
                "cost_usd": cost_usd,
            })

gpu = pd.DataFrame(rows).sort_values(["date", "partner", "cluster_id"]).reset_index(drop=True)
gpu.insert(0, "record_id", [f"GU-{i+1:06d}" for i in range(len(gpu))])
gpu.to_csv(os.path.join(CLEAN, "gpu_usage_clean.csv"), index=False)

# ---------------------------------------------------------------------------
# 2. Second domain: flour mill production (proves nothing is hardcoded to GPUs)
# ---------------------------------------------------------------------------

MILLS = {
    "Ravi Flour Mills": ("Lahore", 180),
    "Indus Grain Processors": ("Rahim Yar Khan", 140),
    "Chenab Atta Works": ("Faisalabad", 110),
}
PRODUCTS = {"Atta": 0.74, "Maida": 0.06, "Suji": 0.04, "Bran": 0.15}  # yield shares
WHEAT_PRICE_PKR_PER_KG = 98.0

mill_rows = []
for mill, (city, capacity_t) in MILLS.items():
    for d_idx, d in enumerate(DATES):
        if d.weekday() == 4 and rng.random() < 0.5:  # some Fridays half shift
            shift_factor = 0.5
        else:
            shift_factor = 1.0
        downtime_h = float(np.clip(rng.exponential(0.8), 0, 10))
        if mill == "Chenab Atta Works" and date(2026, 9, 3) <= d <= date(2026, 9, 6):
            downtime_h = float(rng.uniform(8, 14))  # breakdown
        hours_run = max(0.0, 22 * shift_factor - downtime_h)
        wheat_in_t = round(capacity_t * hours_run / 22 * rng.normal(0.93, 0.04), 2)
        total_yield = float(np.clip(rng.normal(0.985, 0.006), 0.95, 0.995))
        if mill == "Indus Grain Processors" and d >= date(2026, 10, 10):
            total_yield = float(np.clip(rng.normal(0.962, 0.008), 0.93, 0.99))  # moisture problem
        wheat_price = WHEAT_PRICE_PKR_PER_KG * (1 + 0.0012 * d_idx) * rng.normal(1, 0.01)
        for product, share in PRODUCTS.items():
            out_t = round(wheat_in_t * share * total_yield / sum(PRODUCTS.values()), 2)
            mill_rows.append({
                "production_date": d.isoformat(),
                "mill_name": mill,
                "city": city,
                "product": product,
                "wheat_input_tonnes": wheat_in_t,
                "output_tonnes": out_t,
                "machine_hours": round(hours_run, 1),
                "downtime_hours": round(downtime_h, 1),
                "wheat_cost_pkr": round(wheat_in_t * 1000 * wheat_price * share, 0),
                "bags_50kg": int(out_t * 1000 // 50) if product != "Bran" else 0,
            })

mill = pd.DataFrame(mill_rows)
mill.to_csv(os.path.join(CLEAN, "mill_production_clean.csv"), index=False)

# ---------------------------------------------------------------------------
# 3. Messy variants of the GPU dataset, each with a recorded ground truth
# ---------------------------------------------------------------------------

truth = {}


def save(df, name, info, **kw):
    path = os.path.join(MESSY, name)
    df.to_csv(path, index=False, **kw)
    info["rows_in_file"] = int(len(df))
    truth[name] = info


base = gpu.copy()
n = len(base)

# 3.1 Renamed headers (synonyms and casing)
renamed = base.rename(columns={
    "date": "Usage Date",
    "partner": "Client Name",
    "region": "Region",
    "cluster_id": "Cluster",
    "gpu_type": "GPU Model",
    "contract_type": "Plan",
    "gpus_allocated": "GPUs",
    "gpu_hours": "Hrs",
    "avg_utilization_pct": "Util %",
    "jobs_submitted": "Jobs",
    "jobs_failed": "Failed Jobs",
    "top_failure_reason": "Main Error",
    "price_per_gpu_hour_usd": "Rate",
    "cost_usd": "Price",
})
save(renamed, "01_renamed_headers.csv", {
    "purpose": "Synonyms and different casing. Every column should map without the LLM fallback except possibly 'Rate' and 'Plan'.",
    "expected_mapping": {
        "Usage Date": "date", "Client Name": "partner", "Hrs": "gpu_hours",
        "Price": "cost_usd", "Util %": "avg_utilization_pct", "GPUs": "gpus_allocated",
        "Failed Jobs": "jobs_failed", "Jobs": "jobs_submitted", "Rate": "price_per_gpu_hour_usd",
        "Plan": "contract_type", "Main Error": "top_failure_reason", "GPU Model": "gpu_type",
        "Cluster": "cluster_id", "Region": "region",
    },
})

# 3.2 Missing values in key numeric columns
mv = base.copy()
idx_cost = rng.choice(n, 37, replace=False)
idx_hours = rng.choice(np.setdiff1d(np.arange(n), idx_cost), 24, replace=False)
mv.loc[idx_cost, "cost_usd"] = np.nan
mv.loc[idx_hours, "gpu_hours"] = np.nan
save(mv, "02_missing_values.csv", {
    "purpose": "Blank cells in cost_usd and gpu_hours. Must be excluded from totals, never filled.",
    "missing_cost_usd": 37,
    "missing_gpu_hours": 24,
    "missing_record_ids_cost": sorted(base.loc[idx_cost, "record_id"].tolist()),
    "missing_record_ids_gpu_hours": sorted(base.loc[idx_hours, "record_id"].tolist()),
})

# 3.3 Exact duplicates
dup_idx = rng.choice(n, 15, replace=False)
dups = pd.concat([base, base.loc[dup_idx]]).sample(frac=1, random_state=SEED).reset_index(drop=True)
save(dups, "03_duplicates.csv", {
    "purpose": "15 exact duplicate rows shuffled in. Should be removed; totals should match the clean file.",
    "exact_duplicates_added": 15,
    "duplicated_record_ids": sorted(base.loc[dup_idx, "record_id"].tolist()),
})

# 3.4 Missing day (all rows for one date removed) plus a missing weekend
missing_dates = ["2026-08-12", "2026-10-18", "2026-10-19"]
md = base[~base["date"].isin(missing_dates)].copy()
save(md, "04_missing_days.csv", {
    "purpose": "Entire dates removed. Must be reported as gaps, not treated as zero usage. Weeks containing them are incomplete.",
    "missing_dates": missing_dates,
    "rows_removed": int(len(base) - len(md)),
})

# 3.5 Impossible values
iv = base.copy()
neg_idx = rng.choice(n, 6, replace=False)
over_idx = rng.choice(np.setdiff1d(np.arange(n), neg_idx), 5, replace=False)
fail_idx = rng.choice(np.setdiff1d(np.arange(n), np.concatenate([neg_idx, over_idx])), 4, replace=False)
iv.loc[neg_idx, "gpu_hours"] = -iv.loc[neg_idx, "gpu_hours"]
iv.loc[over_idx, "avg_utilization_pct"] = rng.uniform(101, 180, 5).round(1)
iv.loc[fail_idx, "jobs_failed"] = iv.loc[fail_idx, "jobs_submitted"] + rng.integers(5, 50, 4)
save(iv, "05_impossible_values.csv", {
    "purpose": "Negative gpu_hours, utilization above 100%, and more failed jobs than submitted. Each row should be flagged invalid.",
    "negative_gpu_hours": 6,
    "utilization_over_100": 5,
    "failed_gt_submitted": 4,
    "invalid_record_ids": sorted(base.loc[np.concatenate([neg_idx, over_idx, fail_idx]), "record_id"].tolist()),
})

# 3.6 Wrong types and dirty formats
wt = base.copy().astype({"cost_usd": "object", "gpu_hours": "object", "date": "object"})
money_idx = rng.choice(n, 200, replace=False)
wt.loc[money_idx, "cost_usd"] = wt.loc[money_idx, "cost_usd"].map(lambda v: f"${v:,.2f}")
text_idx = rng.choice(np.setdiff1d(np.arange(n), money_idx), 8, replace=False)
wt.loc[text_idx, "gpu_hours"] = ["N/A", "abc", "--", "pending", "#REF!", "TBD", " ", "null"]
date_idx = rng.choice(n, 60, replace=False)
wt.loc[date_idx, "date"] = pd.to_datetime(wt.loc[date_idx, "date"]).dt.strftime("%d/%m/%Y")
bad_date_idx = rng.choice(np.setdiff1d(np.arange(n), date_idx), 3, replace=False)
wt.loc[bad_date_idx, "date"] = ["2026-13-01", "31/02/2026", "yesterday"]
save(wt, "06_wrong_types_and_formats.csv", {
    "purpose": "Currency strings like $1,234.50 (should parse), mixed date formats DD/MM/YYYY (should parse), non-numeric text in gpu_hours and impossible dates (should be flagged invalid).",
    "currency_formatted_cost_rows": 200,
    "non_numeric_gpu_hours_rows": 8,
    "ddmmyyyy_date_rows": 60,
    "unparseable_date_rows": 3,
    "unparseable_record_ids": sorted(base.loc[np.concatenate([text_idx, bad_date_idx]), "record_id"].tolist()),
})

# 3.7 Outlier spikes (valid but suspicious)
sp = base.copy()
spike_idx = rng.choice(n, 4, replace=False)
sp.loc[spike_idx, "cost_usd"] = (sp.loc[spike_idx, "cost_usd"] * rng.uniform(40, 120, 4)).round(2)
save(sp, "07_outlier_spikes.csv", {
    "purpose": "Four cost values multiplied 40-120x. Kept in totals but flagged as unusual.",
    "spike_record_ids": sorted(base.loc[spike_idx, "record_id"].tolist()),
})

# 3.8 Meaningless headers (forces profile-based mapping)
cols = list(base.columns)
meaningless = base.copy()
meaningless.columns = [f"Col_{i+1}" for i in range(len(cols))]
save(meaningless, "08_meaningless_headers.csv", {
    "purpose": "Headers Col_1..Col_N. Mapping must come from the column profile; uncertain columns should trigger the consent prompt.",
    "true_columns": {f"Col_{i+1}": c for i, c in enumerate(cols)},
})

# 3.9 Foreign-language headers
es = base.rename(columns={
    "record_id": "id_registro", "date": "Fecha", "partner": "Cliente", "region": "Región",
    "cluster_id": "Clúster", "gpu_type": "Tipo GPU", "contract_type": "Contrato",
    "gpus_allocated": "GPUs asignadas", "gpu_hours": "Horas GPU", "avg_utilization_pct": "Utilización %",
    "jobs_submitted": "Trabajos", "jobs_failed": "Trabajos fallidos", "top_failure_reason": "Error principal",
    "price_per_gpu_hour_usd": "Tarifa", "cost_usd": "Monto",
})
save(es, "09_spanish_headers.csv", {
    "purpose": "Spanish headers. Synonym list will miss most; LLM mapping from profile should resolve them.",
    "expected_mapping": {"Fecha": "date", "Cliente": "partner", "Horas GPU": "gpu_hours", "Monto": "cost_usd"},
})

# 3.10 Extra unplanned columns
ex = base.copy()
ex["project_code"] = rng.choice(["PRJ-ALPHA", "PRJ-BETA", "PRJ-GAMMA", "PRJ-DELTA"], n)
ex["account_manager"] = ex["partner"].map({p: m for p, m in zip(PARTNERS, ["S. Rao", "J. Kim", "A. Weber", "A. Weber", "M. Tan", "J. Kim", "S. Rao", "A. Weber"])})
save(ex, "10_extra_columns.csv", {
    "purpose": "Two unplanned columns. Should be kept and usable in chat (e.g., 'spend by account manager').",
    "extra_columns": ["project_code", "account_manager"],
})

# 3.11 Minimal columns only
mini = base[["date", "partner", "cost_usd"]].copy()
save(mini, "11_minimal_columns.csv", {
    "purpose": "Only date, partner, cost. Report should show cost sections only and skip GPU, utilization and failure sections without crashing.",
})

# 3.12 Kitchen sink: everything at once
ks = renamed.copy()
ks = ks[~ks["Usage Date"].isin(["2026-09-22"])].reset_index(drop=True)
ks_missing_idx = rng.choice(len(ks), 30, replace=False)
ks["Price"] = ks["Price"].astype(object)
ks.loc[ks_missing_idx, "Price"] = np.nan
ks_currency_mask = ks["Price"].notna() & (rng.random(len(ks)) < 0.3)
ks.loc[ks_currency_mask, "Price"] = ks.loc[ks_currency_mask, "Price"].map(lambda v: f"${v:,.2f}")
# duplicates added last so they stay exact copies
ks_dup_rows = ks[ks["Price"].notna()].sample(10, random_state=SEED)
ks = pd.concat([ks, ks_dup_rows]).sample(frac=1, random_state=SEED).reset_index(drop=True)
save(ks, "12_kitchen_sink.csv", {
    "purpose": "Renamed headers + one missing date + 30 missing Price + about 30% of Price as currency strings + 10 exact duplicates. Integration test.",
    "missing_dates": ["2026-09-22"],
    "missing_price": 30,
    "currency_formatted_price_rows_before_duplicates": int(ks_currency_mask.sum()),
    "exact_duplicates_added": 10,
})

# 3.13 Empty file with header only, and a non-CSV file
pd.DataFrame(columns=base.columns).to_csv(os.path.join(MESSY, "13_header_only.csv"), index=False)
truth["13_header_only.csv"] = {"purpose": "Header row, zero data rows. Should stop with a clear message.", "rows_in_file": 0}
with open(os.path.join(MESSY, "14_not_a_csv.csv"), "w", encoding="utf-8") as f:
    f.write("This is a meeting note, not a data file.\nAgenda: Q4 GPU planning\n- discuss B200 capacity\n")
truth["14_not_a_csv.csv"] = {"purpose": "Plain text with a .csv extension. Should be rejected with a clear message."}

# 3.14 Semicolon separator and European decimals
eu = base.copy()
eu.to_csv(os.path.join(MESSY, "15_semicolon_eu_decimals.csv"), index=False, sep=";", decimal=",")
truth["15_semicolon_eu_decimals.csv"] = {"purpose": "Semicolon delimiter and comma decimals (European Excel export). Should be sniffed and parsed.", "rows_in_file": int(len(eu))}

# ---------------------------------------------------------------------------
# 4. Ground truth for the clean file (answers the analyzer should reproduce)
# ---------------------------------------------------------------------------

g = gpu.copy()
g["date"] = pd.to_datetime(g["date"])
g["month"] = g["date"].dt.strftime("%Y-%m")
oct_ = g[g["month"] == "2026-10"]
sep_ = g[g["month"] == "2026-09"]

clean_truth = {
    "rows": int(len(g)),
    "date_range": [g["date"].min().date().isoformat(), g["date"].max().date().isoformat()],
    "partners": sorted(g["partner"].unique().tolist()),
    "total_cost_usd": round(float(g["cost_usd"].sum()), 2),
    "total_gpu_hours": round(float(g["gpu_hours"].sum()), 1),
    "cost_by_month_usd": {k: round(float(v), 2) for k, v in g.groupby("month")["cost_usd"].sum().items()},
    "october_cost_by_region_usd": {k: round(float(v), 2) for k, v in oct_.groupby("region")["cost_usd"].sum().sort_values(ascending=False).items()},
    "top_region_october": oct_.groupby("region")["cost_usd"].sum().idxmax(),
    "partner_cost_change_sep_to_oct_pct": {
        p: round(float((oct_[oct_.partner == p]["cost_usd"].sum() / sep_[sep_.partner == p]["cost_usd"].sum() - 1) * 100), 1)
        for p in g["partner"].unique() if sep_[sep_.partner == p]["cost_usd"].sum() > 0
    },
    "highest_failure_day": {
        "date": g.groupby("date")["jobs_failed"].sum().idxmax().date().isoformat(),
        "jobs_failed": int(g.groupby("date")["jobs_failed"].sum().max()),
    },
    "stories_baked_in": {p: c["story"] for p, c in PARTNERS.items()} | {
        "us-west outage": f"{EVENTS['outage_usw2'].isoformat()}: utilization drops, NODE_FAILURE spike on usw2 clusters",
        "H100 price drop": f"{EVENTS['price_change_h100'].isoformat()}: on-demand H100 price falls 8%",
    },
}
truth["gpu_usage_clean.csv"] = clean_truth

m = mill.copy()
truth["mill_production_clean.csv"] = {
    "rows": int(len(m)),
    "total_output_tonnes_by_mill": {k: round(float(v), 1) for k, v in m.groupby("mill_name")["output_tonnes"].sum().items()},
    "stories_baked_in": {
        "Chenab Atta Works": "breakdown 3-6 Sep 2026: high downtime, low output",
        "Indus Grain Processors": "from 10 Oct 2026 total yield drops (moisture problem)",
        "Fridays": "about half of Fridays run a half shift",
    },
}

with open(os.path.join(OUT, "ground_truth.json"), "w", encoding="utf-8") as f:
    json.dump(truth, f, indent=2, ensure_ascii=False)

print(f"gpu_usage_clean.csv: {len(gpu):,} rows")
print(f"mill_production_clean.csv: {len(mill):,} rows")
print(f"messy files: {len(os.listdir(MESSY))}")
