# NV-A synthetic test data

All data is synthetic and seeded (`SEED = 42`). Every company, cluster and mill name is invented. Re-run `python generate_data.py` to rebuild identical files.

```
clean/
  gpu_usage_clean.csv          1,413 rows · 1 Jul – 31 Oct 2026 · one row per day × partner × cluster
  mill_production_clean.csv    1,476 rows · same period · one row per day × mill × product
messy/
  01–15                        broken variants of the GPU file, one problem type each (12 combines several)
ground_truth.json              what was injected into each messy file, plus answers the analyzer should reproduce
generate_data.py               the generator
```

## gpu_usage_clean.csv

| Column | Type | Meaning |
| --- | --- | --- |
| record_id | text | Unique row id, `GU-000001` |
| date | date (YYYY-MM-DD) | Usage day |
| partner | text | Cloud customer (8 partners) |
| region | text | us-east, us-west, eu-west, ap-southeast |
| cluster_id | text | e.g. `use1-h100-a` |
| gpu_type | text | H100, H200, B200, A100, L40S |
| contract_type | text | reserved, on_demand, spot |
| gpus_allocated | integer | GPUs assigned that day |
| gpu_hours | float | Hours actually used = GPUs × 24 × utilization |
| avg_utilization_pct | float | 0–100 |
| jobs_submitted | integer | Jobs started |
| jobs_failed | integer | Jobs failed (always ≤ submitted in the clean file) |
| top_failure_reason | text | Most common failure that day; blank when no failures |
| price_per_gpu_hour_usd | float | Rate applied |
| cost_usd | float | Reserved: billed on allocation × 24h. On-demand and spot: billed on gpu_hours |

### Stories baked into the data (what a good report should find)

| Story | Where to see it |
| --- | --- |
| Northwind AI grows fast and adds B200 from 4 Aug | Monthly cost ~$0.6M → ~$1.9M |
| Quanta Labs is a churn risk | Cost falls every month; allocation cut 40% on 1 Oct; utilization drops from ~78% to ~47% from 10 Sep, so they pay for GPUs they don't use |
| Lumen Speech onboards 15 Sep | No rows before; ramps from 8 to ~160 GPUs in a week |
| us-west outage on 19 Aug | Utilization ~26%, 171 failed jobs on usw2 clusters, NODE_FAILURE |
| H100 on-demand price drops 8% on 1 Sep | `price_per_gpu_hour_usd` 3.40 → 3.13 |
| Kestrel Vision is weekday-heavy | Weekends run at ~55% of weekday allocation |
| Atlas Genomics is volatile | Spot contract, high day-to-day noise, PREEMPTED failures |
| Meridian Health AI runs inference | Low utilization (~55%), many small jobs, very low failure rate |

Watch-out built in: September has 30 days and October has 31, so raw month-over-month totals overstate growth by about 3%. A careful report compares cost per day.

## mill_production_clean.csv

A second, unrelated domain to prove the analyzer is not hardcoded to GPU data.

| Column | Type | Meaning |
| --- | --- | --- |
| production_date | date | Production day |
| mill_name | text | 3 flour mills |
| city | text | Lahore, Rahim Yar Khan, Faisalabad |
| product | text | Atta, Maida, Suji, Bran |
| wheat_input_tonnes | float | Wheat milled that day (repeated on each product row) |
| output_tonnes | float | Output of this product |
| machine_hours | float | Hours run |
| downtime_hours | float | Hours stopped |
| wheat_cost_pkr | float | Wheat cost allocated to this product |
| bags_50kg | integer | 50 kg bags packed (0 for bran) |

Stories: Chenab Atta Works breakdown 3–6 Sep; Indus Grain Processors yield drops from 10 Oct; about half of Fridays run a half shift.

Watch-out built in: `wheat_input_tonnes` repeats on each of the 4 product rows. Summing it across rows counts the wheat four times. A good plan sums it per mill per day once.

## Messy files

| File | Problem injected | Expected behaviour |
| --- | --- | --- |
| 01_renamed_headers | Synonyms: Hrs, Price, Client Name, Util %, Rate, Plan | Map via synonyms and fuzzy matching |
| 02_missing_values | 37 blank cost_usd, 24 blank gpu_hours | Exclude from totals, never fill; report counts |
| 03_duplicates | 15 exact duplicate rows | Remove; totals match the clean file |
| 04_missing_days | 12 Aug, 18 Oct, 19 Oct removed entirely | Report as gaps, not zero; mark weeks incomplete |
| 05_impossible_values | 6 negative hours, 5 utilization > 100, 4 failed > submitted | Flag rows invalid, exclude |
| 06_wrong_types_and_formats | 200 costs like `$1,234.50`, 60 DD/MM/YYYY dates, 8 text values in gpu_hours, 3 impossible dates | Parse currency and DD/MM; flag the 11 unparseable rows |
| 07_outlier_spikes | 4 costs multiplied 40–120× | Keep in totals, flag as unusual |
| 08_meaningless_headers | Col_1 … Col_15 | Map from column profile; consent prompt for uncertain ones |
| 09_spanish_headers | Fecha, Cliente, Horas GPU, Monto … | Synonyms miss; LLM mapping from profile resolves |
| 10_extra_columns | project_code, account_manager added | Keep; usable in chat |
| 11_minimal_columns | Only date, partner, cost_usd | Cost sections only; no crash |
| 12_kitchen_sink | Renamed headers, 1 missing date, 30 missing Price, ~30% currency strings, 10 duplicates | Integration test |
| 13_header_only | Header, zero rows | Stop with a clear message |
| 14_not_a_csv | Plain text with .csv extension | Reject with a clear message |
| 15_semicolon_eu_decimals | `;` separator, `1471,9` decimals | Sniff delimiter and decimal; parse correctly |

Exact record ids for every injected problem are in `ground_truth.json`, so tests can assert row by row.
